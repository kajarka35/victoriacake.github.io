// File: firebase-config.js
export const firebaseConfig = {
  apiKey: "AIzaSyAcvikj3kovixYo4IkOywGlmWqPE7zHsJQ",
   authDomain: "victoriacake-ac574.firebaseapp.com",
   projectId: "victoriacake-ac574",
   storageBucket: "victoriacake-ac574.firebasestorage.app",
   messagingSenderId: "958849252478",
   appId: "1:958849252478:web:06b9529d92b85cf318ac2f",
   measurementId: "G-3FCMNRL6X7"
};